aclTensor 形状与布局：原始笔记及引用依赖

本 ZIP 保留以下相对路径，可解压到 Obsidian 笔记库中查看：

1. Excalidraw/Drawing 2026-10-10 09.43.22.excalidraw.md
   本次博客对应的当前原稿，按原始字节完整保留，未修改文字、图形或压缩绘图数据。

2. Excalidraw/Drawing 2026-10-09 09.41.16.excalidraw.md
   仅摘录原图引用的「# viewshape && viewstrides」完整段落，保留文件名、相对路径和标题，以便原稿中的链接与嵌入引用解析。
   此依赖文件不包含无关段落、其他原图或压缩绘图数据，不是该日期原笔记的完整副本。

打开方式

- 将 ZIP 内容解压到 Obsidian 笔记库根目录，保留 Excalidraw/ 目录结构。
- 安装并启用 Obsidian Excalidraw 插件，再打开 2026-10-10 的原稿并切换到 Excalidraw 视图。
- 2026-10-09 的依赖文件是被引用段落的 Markdown 摘录，用于提供嵌入内容。
- 博客提供的 PNG 已包含原图所有嵌入内容，可直接查看，无需安装插件。

原稿中的表述保持原样；博客正文补充了适用条件与技术说明。
